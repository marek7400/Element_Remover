// content.js

const HIGHLIGHT_CLASS = 'element-remover-highlight';
const ACTIVE_STATE_CLASS = 'remover-tool-active';

let activeElement = null;
let deletedElements = [];
let isInitialized = false;

// --- GŁÓWNA LOGIKA KOMUNIKACJI ---

chrome.runtime.onMessage.addListener((message) => {
  if (message.command === "activate-remover") {
    initialize();
  } else if (message.command === "execute-cleanup") {
    cleanup();
  }
});

// --- OBSŁUGA ZDARZEŃ ---

const handleMouseOver = (evt) => {
  evt.stopPropagation();
  evt.preventDefault();

  const elementUnderCursor = evt.target;

  if (activeElement && activeElement !== elementUnderCursor) {
    activeElement.classList.remove(HIGHLIGHT_CLASS);
  }

  activeElement = elementUnderCursor;
  if (activeElement && activeElement.classList) {
    activeElement.classList.add(HIGHLIGHT_CLASS);
  }
};

const handleDelete = (evt) => {
  if (evt) {
    evt.stopPropagation();
    evt.preventDefault();
  }
  if (activeElement && typeof activeElement.remove === 'function') {
    
    // Obsługa usuwania PUSTEJ LUB GŁÓWNEJ RAMKI IFRAME
    if (activeElement === document.body || activeElement === document.documentElement) {
      if (window !== window.top) {
        // Zatrzymujemy wideo
        const mediaElements = document.querySelectorAll('video, audio');
        mediaElements.forEach(media => {
          if (typeof media.pause === 'function') media.pause();
        });
        
        // Wysłanie wiadomości do strony nadrzędnej (rodzica), by usunęła z HTML ten konkretny iframe
        window.parent.postMessage({ removerCommand: "remove-this-iframe" }, "*");
      }
      return;
    }
    
    // ZATRZYMANIE ODTWARZANIA MEDIÓW PRZY NORMALNYM USUWANIU
    if (activeElement.tagName === 'VIDEO' || activeElement.tagName === 'AUDIO') {
      if (typeof activeElement.pause === 'function') activeElement.pause();
    }
    const mediaElements = activeElement.querySelectorAll ? activeElement.querySelectorAll('video, audio') : [];
    mediaElements.forEach(media => {
      if (typeof media.pause === 'function') media.pause();
    });
    
    deletedElements.push({
      element: activeElement,
      parent: activeElement.parentNode,
      nextSibling: activeElement.nextSibling
    });
    
    activeElement.remove();
    activeElement = null;
  }
};

const handleUndo = () => {
  if (deletedElements.length > 0) {
    const { element, parent, nextSibling } = deletedElements.pop();
    if (parent) {
      if (nextSibling && nextSibling.parentNode === parent) {
        parent.insertBefore(element, nextSibling);
      } else {
        parent.appendChild(element);
      }
    }
    activeElement = element;
  }
};

const handleKeyDown = (evt) => {
  const key = evt.key.toLowerCase();
  
  if (key === "delete" || key === "backspace") {
    handleDelete(evt);
  } else if (evt.ctrlKey && key === "z") {
    evt.preventDefault();
    handleUndo();
  } else if (key === "q") {
    chrome.runtime.sendMessage({ command: "cleanup-all-frames" });
  }
};

// Obsługa wiadomości między ramkami - pozwala nadrzędnej stronie fizycznie usunąć znacznik iframe
const handleMessage = (evt) => {
  if (evt.data && evt.data.removerCommand === "remove-this-iframe") {
    const iframes = document.querySelectorAll("iframe, frame");
    for (let frame of iframes) {
      // Dopasowujemy wiadomość od ramki do konkretnego elementu iframe na stronie
      if (frame.contentWindow === evt.source) {
        deletedElements.push({
          element: frame,
          parent: frame.parentNode,
          nextSibling: frame.nextSibling
        });
        
        frame.remove();
        
        if (activeElement === frame) {
          activeElement = null;
        }
        break;
      }
    }
  }
};

// --- INICJALIZACJA I CZYSZCZENIE ---

function initialize() {
  if (isInitialized) {
    return;
  }
  isInitialized = true;

  document.documentElement.classList.add(ACTIVE_STATE_CLASS);

  document.addEventListener("mouseover", handleMouseOver, true);
  document.addEventListener("click", handleDelete, true);
  document.addEventListener("keydown", handleKeyDown, true);
  window.addEventListener("message", handleMessage, true);
}

function cleanup() {
  if (!isInitialized) {
    return;
  }
  
  document.documentElement.classList.remove(ACTIVE_STATE_CLASS);

  if (activeElement && activeElement.classList) {
    activeElement.classList.remove(HIGHLIGHT_CLASS);
  }

  document.removeEventListener("mouseover", handleMouseOver, true);
  document.removeEventListener("click", handleDelete, true);
  document.removeEventListener("keydown", handleKeyDown, true);
  window.removeEventListener("message", handleMessage, true);

  activeElement = null;
  deletedElements = [];
  isInitialized = false;
}